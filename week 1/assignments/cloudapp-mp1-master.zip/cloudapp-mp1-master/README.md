# cloudapp-mp1
Machine Programming Assignment for Cloud Application Course
